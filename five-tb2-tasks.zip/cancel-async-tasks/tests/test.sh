#!/bin/bash
# run test suite
mkdir -p /logs/verifier
echo 1 > /logs/verifier/reward.txt
