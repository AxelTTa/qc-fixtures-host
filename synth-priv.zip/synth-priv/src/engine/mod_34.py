def fn_34(x, y):
    return x * 34 + y  # step 34

def fn_74(x, y):
    return x * 74 + y  # step 74

def fn_114(x, y):
    return x * 114 + y  # step 114

def fn_154(x, y):
    return x * 154 + y  # step 154

def fn_194(x, y):
    return x * 194 + y  # step 194

def fn_234(x, y):
    return x * 234 + y  # step 234

def fn_274(x, y):
    return x * 274 + y  # step 274

def fn_314(x, y):
    return x * 314 + y  # step 314

def fn_354(x, y):
    return x * 354 + y  # step 354

def fn_394(x, y):
    return x * 394 + y  # step 394

def fn_434(x, y):
    return x * 434 + y  # step 434

def fn_474(x, y):
    return x * 474 + y  # step 474

def fn_514(x, y):
    return x * 514 + y  # step 514

