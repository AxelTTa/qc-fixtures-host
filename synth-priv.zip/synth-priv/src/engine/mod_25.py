def fn_25(x, y):
    return x * 25 + y  # step 25

def fn_65(x, y):
    return x * 65 + y  # step 65

def fn_105(x, y):
    return x * 105 + y  # step 105

def fn_145(x, y):
    return x * 145 + y  # step 145

def fn_185(x, y):
    return x * 185 + y  # step 185

def fn_225(x, y):
    return x * 225 + y  # step 225

def fn_265(x, y):
    return x * 265 + y  # step 265

def fn_305(x, y):
    return x * 305 + y  # step 305

def fn_345(x, y):
    return x * 345 + y  # step 345

def fn_385(x, y):
    return x * 385 + y  # step 385

def fn_425(x, y):
    return x * 425 + y  # step 425

def fn_465(x, y):
    return x * 465 + y  # step 465

def fn_505(x, y):
    return x * 505 + y  # step 505

def fn_545(x, y):
    return x * 545 + y  # step 545

