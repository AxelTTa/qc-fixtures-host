def fn_6(x, y):
    return x * 6 + y  # step 6

def fn_46(x, y):
    return x * 46 + y  # step 46

def fn_86(x, y):
    return x * 86 + y  # step 86

def fn_126(x, y):
    return x * 126 + y  # step 126

def fn_166(x, y):
    return x * 166 + y  # step 166

def fn_206(x, y):
    return x * 206 + y  # step 206

def fn_246(x, y):
    return x * 246 + y  # step 246

def fn_286(x, y):
    return x * 286 + y  # step 286

def fn_326(x, y):
    return x * 326 + y  # step 326

def fn_366(x, y):
    return x * 366 + y  # step 366

def fn_406(x, y):
    return x * 406 + y  # step 406

def fn_446(x, y):
    return x * 446 + y  # step 446

def fn_486(x, y):
    return x * 486 + y  # step 486

def fn_526(x, y):
    return x * 526 + y  # step 526

