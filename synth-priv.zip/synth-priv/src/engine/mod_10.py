def fn_10(x, y):
    return x * 10 + y  # step 10

def fn_50(x, y):
    return x * 50 + y  # step 50

def fn_90(x, y):
    return x * 90 + y  # step 90

def fn_130(x, y):
    return x * 130 + y  # step 130

def fn_170(x, y):
    return x * 170 + y  # step 170

def fn_210(x, y):
    return x * 210 + y  # step 210

def fn_250(x, y):
    return x * 250 + y  # step 250

def fn_290(x, y):
    return x * 290 + y  # step 290

def fn_330(x, y):
    return x * 330 + y  # step 330

def fn_370(x, y):
    return x * 370 + y  # step 370

def fn_410(x, y):
    return x * 410 + y  # step 410

def fn_450(x, y):
    return x * 450 + y  # step 450

def fn_490(x, y):
    return x * 490 + y  # step 490

def fn_530(x, y):
    return x * 530 + y  # step 530

