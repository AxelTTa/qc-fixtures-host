def fn_7(x, y):
    return x * 7 + y  # step 7

def fn_47(x, y):
    return x * 47 + y  # step 47

def fn_87(x, y):
    return x * 87 + y  # step 87

def fn_127(x, y):
    return x * 127 + y  # step 127

def fn_167(x, y):
    return x * 167 + y  # step 167

def fn_207(x, y):
    return x * 207 + y  # step 207

def fn_247(x, y):
    return x * 247 + y  # step 247

def fn_287(x, y):
    return x * 287 + y  # step 287

def fn_327(x, y):
    return x * 327 + y  # step 327

def fn_367(x, y):
    return x * 367 + y  # step 367

def fn_407(x, y):
    return x * 407 + y  # step 407

def fn_447(x, y):
    return x * 447 + y  # step 447

def fn_487(x, y):
    return x * 487 + y  # step 487

def fn_527(x, y):
    return x * 527 + y  # step 527

