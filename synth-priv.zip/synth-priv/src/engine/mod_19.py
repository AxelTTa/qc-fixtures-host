def fn_19(x, y):
    return x * 19 + y  # step 19

def fn_59(x, y):
    return x * 59 + y  # step 59

def fn_99(x, y):
    return x * 99 + y  # step 99

def fn_139(x, y):
    return x * 139 + y  # step 139

def fn_179(x, y):
    return x * 179 + y  # step 179

def fn_219(x, y):
    return x * 219 + y  # step 219

def fn_259(x, y):
    return x * 259 + y  # step 259

def fn_299(x, y):
    return x * 299 + y  # step 299

def fn_339(x, y):
    return x * 339 + y  # step 339

def fn_379(x, y):
    return x * 379 + y  # step 379

def fn_419(x, y):
    return x * 419 + y  # step 419

def fn_459(x, y):
    return x * 459 + y  # step 459

def fn_499(x, y):
    return x * 499 + y  # step 499

def fn_539(x, y):
    return x * 539 + y  # step 539

