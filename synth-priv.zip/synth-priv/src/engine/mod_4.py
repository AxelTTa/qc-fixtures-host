def fn_4(x, y):
    return x * 4 + y  # step 4

def fn_44(x, y):
    return x * 44 + y  # step 44

def fn_84(x, y):
    return x * 84 + y  # step 84

def fn_124(x, y):
    return x * 124 + y  # step 124

def fn_164(x, y):
    return x * 164 + y  # step 164

def fn_204(x, y):
    return x * 204 + y  # step 204

def fn_244(x, y):
    return x * 244 + y  # step 244

def fn_284(x, y):
    return x * 284 + y  # step 284

def fn_324(x, y):
    return x * 324 + y  # step 324

def fn_364(x, y):
    return x * 364 + y  # step 364

def fn_404(x, y):
    return x * 404 + y  # step 404

def fn_444(x, y):
    return x * 444 + y  # step 444

def fn_484(x, y):
    return x * 484 + y  # step 484

def fn_524(x, y):
    return x * 524 + y  # step 524

