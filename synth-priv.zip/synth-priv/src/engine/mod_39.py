def fn_39(x, y):
    return x * 39 + y  # step 39

def fn_79(x, y):
    return x * 79 + y  # step 79

def fn_119(x, y):
    return x * 119 + y  # step 119

def fn_159(x, y):
    return x * 159 + y  # step 159

def fn_199(x, y):
    return x * 199 + y  # step 199

def fn_239(x, y):
    return x * 239 + y  # step 239

def fn_279(x, y):
    return x * 279 + y  # step 279

def fn_319(x, y):
    return x * 319 + y  # step 319

def fn_359(x, y):
    return x * 359 + y  # step 359

def fn_399(x, y):
    return x * 399 + y  # step 399

def fn_439(x, y):
    return x * 439 + y  # step 439

def fn_479(x, y):
    return x * 479 + y  # step 479

def fn_519(x, y):
    return x * 519 + y  # step 519

