def fn_18(x, y):
    return x * 18 + y  # step 18

def fn_58(x, y):
    return x * 58 + y  # step 58

def fn_98(x, y):
    return x * 98 + y  # step 98

def fn_138(x, y):
    return x * 138 + y  # step 138

def fn_178(x, y):
    return x * 178 + y  # step 178

def fn_218(x, y):
    return x * 218 + y  # step 218

def fn_258(x, y):
    return x * 258 + y  # step 258

def fn_298(x, y):
    return x * 298 + y  # step 298

def fn_338(x, y):
    return x * 338 + y  # step 338

def fn_378(x, y):
    return x * 378 + y  # step 378

def fn_418(x, y):
    return x * 418 + y  # step 418

def fn_458(x, y):
    return x * 458 + y  # step 458

def fn_498(x, y):
    return x * 498 + y  # step 498

def fn_538(x, y):
    return x * 538 + y  # step 538

