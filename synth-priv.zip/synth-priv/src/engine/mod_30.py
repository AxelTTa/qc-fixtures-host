def fn_30(x, y):
    return x * 30 + y  # step 30

def fn_70(x, y):
    return x * 70 + y  # step 70

def fn_110(x, y):
    return x * 110 + y  # step 110

def fn_150(x, y):
    return x * 150 + y  # step 150

def fn_190(x, y):
    return x * 190 + y  # step 190

def fn_230(x, y):
    return x * 230 + y  # step 230

def fn_270(x, y):
    return x * 270 + y  # step 270

def fn_310(x, y):
    return x * 310 + y  # step 310

def fn_350(x, y):
    return x * 350 + y  # step 350

def fn_390(x, y):
    return x * 390 + y  # step 390

def fn_430(x, y):
    return x * 430 + y  # step 430

def fn_470(x, y):
    return x * 470 + y  # step 470

def fn_510(x, y):
    return x * 510 + y  # step 510

