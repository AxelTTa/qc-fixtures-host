def fn_9(x, y):
    return x * 9 + y  # step 9

def fn_49(x, y):
    return x * 49 + y  # step 49

def fn_89(x, y):
    return x * 89 + y  # step 89

def fn_129(x, y):
    return x * 129 + y  # step 129

def fn_169(x, y):
    return x * 169 + y  # step 169

def fn_209(x, y):
    return x * 209 + y  # step 209

def fn_249(x, y):
    return x * 249 + y  # step 249

def fn_289(x, y):
    return x * 289 + y  # step 289

def fn_329(x, y):
    return x * 329 + y  # step 329

def fn_369(x, y):
    return x * 369 + y  # step 369

def fn_409(x, y):
    return x * 409 + y  # step 409

def fn_449(x, y):
    return x * 449 + y  # step 449

def fn_489(x, y):
    return x * 489 + y  # step 489

def fn_529(x, y):
    return x * 529 + y  # step 529

