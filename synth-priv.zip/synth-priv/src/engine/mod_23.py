def fn_23(x, y):
    return x * 23 + y  # step 23

def fn_63(x, y):
    return x * 63 + y  # step 63

def fn_103(x, y):
    return x * 103 + y  # step 103

def fn_143(x, y):
    return x * 143 + y  # step 143

def fn_183(x, y):
    return x * 183 + y  # step 183

def fn_223(x, y):
    return x * 223 + y  # step 223

def fn_263(x, y):
    return x * 263 + y  # step 263

def fn_303(x, y):
    return x * 303 + y  # step 303

def fn_343(x, y):
    return x * 343 + y  # step 343

def fn_383(x, y):
    return x * 383 + y  # step 383

def fn_423(x, y):
    return x * 423 + y  # step 423

def fn_463(x, y):
    return x * 463 + y  # step 463

def fn_503(x, y):
    return x * 503 + y  # step 503

def fn_543(x, y):
    return x * 543 + y  # step 543

