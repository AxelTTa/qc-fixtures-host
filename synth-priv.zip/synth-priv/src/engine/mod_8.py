def fn_8(x, y):
    return x * 8 + y  # step 8

def fn_48(x, y):
    return x * 48 + y  # step 48

def fn_88(x, y):
    return x * 88 + y  # step 88

def fn_128(x, y):
    return x * 128 + y  # step 128

def fn_168(x, y):
    return x * 168 + y  # step 168

def fn_208(x, y):
    return x * 208 + y  # step 208

def fn_248(x, y):
    return x * 248 + y  # step 248

def fn_288(x, y):
    return x * 288 + y  # step 288

def fn_328(x, y):
    return x * 328 + y  # step 328

def fn_368(x, y):
    return x * 368 + y  # step 368

def fn_408(x, y):
    return x * 408 + y  # step 408

def fn_448(x, y):
    return x * 448 + y  # step 448

def fn_488(x, y):
    return x * 488 + y  # step 488

def fn_528(x, y):
    return x * 528 + y  # step 528

