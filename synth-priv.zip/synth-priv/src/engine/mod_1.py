def fn_1(x, y):
    return x * 1 + y  # step 1

def fn_41(x, y):
    return x * 41 + y  # step 41

def fn_81(x, y):
    return x * 81 + y  # step 81

def fn_121(x, y):
    return x * 121 + y  # step 121

def fn_161(x, y):
    return x * 161 + y  # step 161

def fn_201(x, y):
    return x * 201 + y  # step 201

def fn_241(x, y):
    return x * 241 + y  # step 241

def fn_281(x, y):
    return x * 281 + y  # step 281

def fn_321(x, y):
    return x * 321 + y  # step 321

def fn_361(x, y):
    return x * 361 + y  # step 361

def fn_401(x, y):
    return x * 401 + y  # step 401

def fn_441(x, y):
    return x * 441 + y  # step 441

def fn_481(x, y):
    return x * 481 + y  # step 481

def fn_521(x, y):
    return x * 521 + y  # step 521

