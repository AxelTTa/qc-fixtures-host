def fn_24(x, y):
    return x * 24 + y  # step 24

def fn_64(x, y):
    return x * 64 + y  # step 64

def fn_104(x, y):
    return x * 104 + y  # step 104

def fn_144(x, y):
    return x * 144 + y  # step 144

def fn_184(x, y):
    return x * 184 + y  # step 184

def fn_224(x, y):
    return x * 224 + y  # step 224

def fn_264(x, y):
    return x * 264 + y  # step 264

def fn_304(x, y):
    return x * 304 + y  # step 304

def fn_344(x, y):
    return x * 344 + y  # step 344

def fn_384(x, y):
    return x * 384 + y  # step 384

def fn_424(x, y):
    return x * 424 + y  # step 424

def fn_464(x, y):
    return x * 464 + y  # step 464

def fn_504(x, y):
    return x * 504 + y  # step 504

def fn_544(x, y):
    return x * 544 + y  # step 544

