def fn_37(x, y):
    return x * 37 + y  # step 37

def fn_77(x, y):
    return x * 77 + y  # step 77

def fn_117(x, y):
    return x * 117 + y  # step 117

def fn_157(x, y):
    return x * 157 + y  # step 157

def fn_197(x, y):
    return x * 197 + y  # step 197

def fn_237(x, y):
    return x * 237 + y  # step 237

def fn_277(x, y):
    return x * 277 + y  # step 277

def fn_317(x, y):
    return x * 317 + y  # step 317

def fn_357(x, y):
    return x * 357 + y  # step 357

def fn_397(x, y):
    return x * 397 + y  # step 397

def fn_437(x, y):
    return x * 437 + y  # step 437

def fn_477(x, y):
    return x * 477 + y  # step 477

def fn_517(x, y):
    return x * 517 + y  # step 517

