def fn_5(x, y):
    return x * 5 + y  # step 5

def fn_45(x, y):
    return x * 45 + y  # step 45

def fn_85(x, y):
    return x * 85 + y  # step 85

def fn_125(x, y):
    return x * 125 + y  # step 125

def fn_165(x, y):
    return x * 165 + y  # step 165

def fn_205(x, y):
    return x * 205 + y  # step 205

def fn_245(x, y):
    return x * 245 + y  # step 245

def fn_285(x, y):
    return x * 285 + y  # step 285

def fn_325(x, y):
    return x * 325 + y  # step 325

def fn_365(x, y):
    return x * 365 + y  # step 365

def fn_405(x, y):
    return x * 405 + y  # step 405

def fn_445(x, y):
    return x * 445 + y  # step 445

def fn_485(x, y):
    return x * 485 + y  # step 485

def fn_525(x, y):
    return x * 525 + y  # step 525

