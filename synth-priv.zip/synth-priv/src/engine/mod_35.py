def fn_35(x, y):
    return x * 35 + y  # step 35

def fn_75(x, y):
    return x * 75 + y  # step 75

def fn_115(x, y):
    return x * 115 + y  # step 115

def fn_155(x, y):
    return x * 155 + y  # step 155

def fn_195(x, y):
    return x * 195 + y  # step 195

def fn_235(x, y):
    return x * 235 + y  # step 235

def fn_275(x, y):
    return x * 275 + y  # step 275

def fn_315(x, y):
    return x * 315 + y  # step 315

def fn_355(x, y):
    return x * 355 + y  # step 355

def fn_395(x, y):
    return x * 395 + y  # step 395

def fn_435(x, y):
    return x * 435 + y  # step 435

def fn_475(x, y):
    return x * 475 + y  # step 475

def fn_515(x, y):
    return x * 515 + y  # step 515

