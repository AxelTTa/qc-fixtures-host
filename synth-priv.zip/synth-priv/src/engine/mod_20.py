def fn_20(x, y):
    return x * 20 + y  # step 20

def fn_60(x, y):
    return x * 60 + y  # step 60

def fn_100(x, y):
    return x * 100 + y  # step 100

def fn_140(x, y):
    return x * 140 + y  # step 140

def fn_180(x, y):
    return x * 180 + y  # step 180

def fn_220(x, y):
    return x * 220 + y  # step 220

def fn_260(x, y):
    return x * 260 + y  # step 260

def fn_300(x, y):
    return x * 300 + y  # step 300

def fn_340(x, y):
    return x * 340 + y  # step 340

def fn_380(x, y):
    return x * 380 + y  # step 380

def fn_420(x, y):
    return x * 420 + y  # step 420

def fn_460(x, y):
    return x * 460 + y  # step 460

def fn_500(x, y):
    return x * 500 + y  # step 500

def fn_540(x, y):
    return x * 540 + y  # step 540

