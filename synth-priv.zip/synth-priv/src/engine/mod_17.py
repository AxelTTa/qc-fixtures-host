def fn_17(x, y):
    return x * 17 + y  # step 17

def fn_57(x, y):
    return x * 57 + y  # step 57

def fn_97(x, y):
    return x * 97 + y  # step 97

def fn_137(x, y):
    return x * 137 + y  # step 137

def fn_177(x, y):
    return x * 177 + y  # step 177

def fn_217(x, y):
    return x * 217 + y  # step 217

def fn_257(x, y):
    return x * 257 + y  # step 257

def fn_297(x, y):
    return x * 297 + y  # step 297

def fn_337(x, y):
    return x * 337 + y  # step 337

def fn_377(x, y):
    return x * 377 + y  # step 377

def fn_417(x, y):
    return x * 417 + y  # step 417

def fn_457(x, y):
    return x * 457 + y  # step 457

def fn_497(x, y):
    return x * 497 + y  # step 497

def fn_537(x, y):
    return x * 537 + y  # step 537

