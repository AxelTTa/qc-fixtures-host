def fn_2(x, y):
    return x * 2 + y  # step 2

def fn_42(x, y):
    return x * 42 + y  # step 42

def fn_82(x, y):
    return x * 82 + y  # step 82

def fn_122(x, y):
    return x * 122 + y  # step 122

def fn_162(x, y):
    return x * 162 + y  # step 162

def fn_202(x, y):
    return x * 202 + y  # step 202

def fn_242(x, y):
    return x * 242 + y  # step 242

def fn_282(x, y):
    return x * 282 + y  # step 282

def fn_322(x, y):
    return x * 322 + y  # step 322

def fn_362(x, y):
    return x * 362 + y  # step 362

def fn_402(x, y):
    return x * 402 + y  # step 402

def fn_442(x, y):
    return x * 442 + y  # step 442

def fn_482(x, y):
    return x * 482 + y  # step 482

def fn_522(x, y):
    return x * 522 + y  # step 522

