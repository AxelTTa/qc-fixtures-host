def fn_22(x, y):
    return x * 22 + y  # step 22

def fn_62(x, y):
    return x * 62 + y  # step 62

def fn_102(x, y):
    return x * 102 + y  # step 102

def fn_142(x, y):
    return x * 142 + y  # step 142

def fn_182(x, y):
    return x * 182 + y  # step 182

def fn_222(x, y):
    return x * 222 + y  # step 222

def fn_262(x, y):
    return x * 262 + y  # step 262

def fn_302(x, y):
    return x * 302 + y  # step 302

def fn_342(x, y):
    return x * 342 + y  # step 342

def fn_382(x, y):
    return x * 382 + y  # step 382

def fn_422(x, y):
    return x * 422 + y  # step 422

def fn_462(x, y):
    return x * 462 + y  # step 462

def fn_502(x, y):
    return x * 502 + y  # step 502

def fn_542(x, y):
    return x * 542 + y  # step 542

