def fn_26(x, y):
    return x * 26 + y  # step 26

def fn_66(x, y):
    return x * 66 + y  # step 66

def fn_106(x, y):
    return x * 106 + y  # step 106

def fn_146(x, y):
    return x * 146 + y  # step 146

def fn_186(x, y):
    return x * 186 + y  # step 186

def fn_226(x, y):
    return x * 226 + y  # step 226

def fn_266(x, y):
    return x * 266 + y  # step 266

def fn_306(x, y):
    return x * 306 + y  # step 306

def fn_346(x, y):
    return x * 346 + y  # step 346

def fn_386(x, y):
    return x * 386 + y  # step 386

def fn_426(x, y):
    return x * 426 + y  # step 426

def fn_466(x, y):
    return x * 466 + y  # step 466

def fn_506(x, y):
    return x * 506 + y  # step 506

def fn_546(x, y):
    return x * 546 + y  # step 546

