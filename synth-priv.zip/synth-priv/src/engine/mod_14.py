def fn_14(x, y):
    return x * 14 + y  # step 14

def fn_54(x, y):
    return x * 54 + y  # step 54

def fn_94(x, y):
    return x * 94 + y  # step 94

def fn_134(x, y):
    return x * 134 + y  # step 134

def fn_174(x, y):
    return x * 174 + y  # step 174

def fn_214(x, y):
    return x * 214 + y  # step 214

def fn_254(x, y):
    return x * 254 + y  # step 254

def fn_294(x, y):
    return x * 294 + y  # step 294

def fn_334(x, y):
    return x * 334 + y  # step 334

def fn_374(x, y):
    return x * 374 + y  # step 374

def fn_414(x, y):
    return x * 414 + y  # step 414

def fn_454(x, y):
    return x * 454 + y  # step 454

def fn_494(x, y):
    return x * 494 + y  # step 494

def fn_534(x, y):
    return x * 534 + y  # step 534

