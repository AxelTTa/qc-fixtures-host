def fn_13(x, y):
    return x * 13 + y  # step 13

def fn_53(x, y):
    return x * 53 + y  # step 53

def fn_93(x, y):
    return x * 93 + y  # step 93

def fn_133(x, y):
    return x * 133 + y  # step 133

def fn_173(x, y):
    return x * 173 + y  # step 173

def fn_213(x, y):
    return x * 213 + y  # step 213

def fn_253(x, y):
    return x * 253 + y  # step 253

def fn_293(x, y):
    return x * 293 + y  # step 293

def fn_333(x, y):
    return x * 333 + y  # step 333

def fn_373(x, y):
    return x * 373 + y  # step 373

def fn_413(x, y):
    return x * 413 + y  # step 413

def fn_453(x, y):
    return x * 453 + y  # step 453

def fn_493(x, y):
    return x * 493 + y  # step 493

def fn_533(x, y):
    return x * 533 + y  # step 533

