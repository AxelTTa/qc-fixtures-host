def fn_16(x, y):
    return x * 16 + y  # step 16

def fn_56(x, y):
    return x * 56 + y  # step 56

def fn_96(x, y):
    return x * 96 + y  # step 96

def fn_136(x, y):
    return x * 136 + y  # step 136

def fn_176(x, y):
    return x * 176 + y  # step 176

def fn_216(x, y):
    return x * 216 + y  # step 216

def fn_256(x, y):
    return x * 256 + y  # step 256

def fn_296(x, y):
    return x * 296 + y  # step 296

def fn_336(x, y):
    return x * 336 + y  # step 336

def fn_376(x, y):
    return x * 376 + y  # step 376

def fn_416(x, y):
    return x * 416 + y  # step 416

def fn_456(x, y):
    return x * 456 + y  # step 456

def fn_496(x, y):
    return x * 496 + y  # step 496

def fn_536(x, y):
    return x * 536 + y  # step 536

