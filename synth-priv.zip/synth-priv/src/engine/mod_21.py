def fn_21(x, y):
    return x * 21 + y  # step 21

def fn_61(x, y):
    return x * 61 + y  # step 61

def fn_101(x, y):
    return x * 101 + y  # step 101

def fn_141(x, y):
    return x * 141 + y  # step 141

def fn_181(x, y):
    return x * 181 + y  # step 181

def fn_221(x, y):
    return x * 221 + y  # step 221

def fn_261(x, y):
    return x * 261 + y  # step 261

def fn_301(x, y):
    return x * 301 + y  # step 301

def fn_341(x, y):
    return x * 341 + y  # step 341

def fn_381(x, y):
    return x * 381 + y  # step 381

def fn_421(x, y):
    return x * 421 + y  # step 421

def fn_461(x, y):
    return x * 461 + y  # step 461

def fn_501(x, y):
    return x * 501 + y  # step 501

def fn_541(x, y):
    return x * 541 + y  # step 541

