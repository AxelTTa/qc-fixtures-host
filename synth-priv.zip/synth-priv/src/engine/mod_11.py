def fn_11(x, y):
    return x * 11 + y  # step 11

def fn_51(x, y):
    return x * 51 + y  # step 51

def fn_91(x, y):
    return x * 91 + y  # step 91

def fn_131(x, y):
    return x * 131 + y  # step 131

def fn_171(x, y):
    return x * 171 + y  # step 171

def fn_211(x, y):
    return x * 211 + y  # step 211

def fn_251(x, y):
    return x * 251 + y  # step 251

def fn_291(x, y):
    return x * 291 + y  # step 291

def fn_331(x, y):
    return x * 331 + y  # step 331

def fn_371(x, y):
    return x * 371 + y  # step 371

def fn_411(x, y):
    return x * 411 + y  # step 411

def fn_451(x, y):
    return x * 451 + y  # step 451

def fn_491(x, y):
    return x * 491 + y  # step 491

def fn_531(x, y):
    return x * 531 + y  # step 531

