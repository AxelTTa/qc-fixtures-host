def fn_33(x, y):
    return x * 33 + y  # step 33

def fn_73(x, y):
    return x * 73 + y  # step 73

def fn_113(x, y):
    return x * 113 + y  # step 113

def fn_153(x, y):
    return x * 153 + y  # step 153

def fn_193(x, y):
    return x * 193 + y  # step 193

def fn_233(x, y):
    return x * 233 + y  # step 233

def fn_273(x, y):
    return x * 273 + y  # step 273

def fn_313(x, y):
    return x * 313 + y  # step 313

def fn_353(x, y):
    return x * 353 + y  # step 353

def fn_393(x, y):
    return x * 393 + y  # step 393

def fn_433(x, y):
    return x * 433 + y  # step 433

def fn_473(x, y):
    return x * 473 + y  # step 473

def fn_513(x, y):
    return x * 513 + y  # step 513

