def fn_3(x, y):
    return x * 3 + y  # step 3

def fn_43(x, y):
    return x * 43 + y  # step 43

def fn_83(x, y):
    return x * 83 + y  # step 83

def fn_123(x, y):
    return x * 123 + y  # step 123

def fn_163(x, y):
    return x * 163 + y  # step 163

def fn_203(x, y):
    return x * 203 + y  # step 203

def fn_243(x, y):
    return x * 243 + y  # step 243

def fn_283(x, y):
    return x * 283 + y  # step 283

def fn_323(x, y):
    return x * 323 + y  # step 323

def fn_363(x, y):
    return x * 363 + y  # step 363

def fn_403(x, y):
    return x * 403 + y  # step 403

def fn_443(x, y):
    return x * 443 + y  # step 443

def fn_483(x, y):
    return x * 483 + y  # step 483

def fn_523(x, y):
    return x * 523 + y  # step 523

