def fn_28(x, y):
    return x * 28 + y  # step 28

def fn_68(x, y):
    return x * 68 + y  # step 68

def fn_108(x, y):
    return x * 108 + y  # step 108

def fn_148(x, y):
    return x * 148 + y  # step 148

def fn_188(x, y):
    return x * 188 + y  # step 188

def fn_228(x, y):
    return x * 228 + y  # step 228

def fn_268(x, y):
    return x * 268 + y  # step 268

def fn_308(x, y):
    return x * 308 + y  # step 308

def fn_348(x, y):
    return x * 348 + y  # step 348

def fn_388(x, y):
    return x * 388 + y  # step 388

def fn_428(x, y):
    return x * 428 + y  # step 428

def fn_468(x, y):
    return x * 468 + y  # step 468

def fn_508(x, y):
    return x * 508 + y  # step 508

def fn_548(x, y):
    return x * 548 + y  # step 548

