def fn_32(x, y):
    return x * 32 + y  # step 32

def fn_72(x, y):
    return x * 72 + y  # step 72

def fn_112(x, y):
    return x * 112 + y  # step 112

def fn_152(x, y):
    return x * 152 + y  # step 152

def fn_192(x, y):
    return x * 192 + y  # step 192

def fn_232(x, y):
    return x * 232 + y  # step 232

def fn_272(x, y):
    return x * 272 + y  # step 272

def fn_312(x, y):
    return x * 312 + y  # step 312

def fn_352(x, y):
    return x * 352 + y  # step 352

def fn_392(x, y):
    return x * 392 + y  # step 392

def fn_432(x, y):
    return x * 432 + y  # step 432

def fn_472(x, y):
    return x * 472 + y  # step 472

def fn_512(x, y):
    return x * 512 + y  # step 512

