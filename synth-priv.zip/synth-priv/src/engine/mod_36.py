def fn_36(x, y):
    return x * 36 + y  # step 36

def fn_76(x, y):
    return x * 76 + y  # step 76

def fn_116(x, y):
    return x * 116 + y  # step 116

def fn_156(x, y):
    return x * 156 + y  # step 156

def fn_196(x, y):
    return x * 196 + y  # step 196

def fn_236(x, y):
    return x * 236 + y  # step 236

def fn_276(x, y):
    return x * 276 + y  # step 276

def fn_316(x, y):
    return x * 316 + y  # step 316

def fn_356(x, y):
    return x * 356 + y  # step 356

def fn_396(x, y):
    return x * 396 + y  # step 396

def fn_436(x, y):
    return x * 436 + y  # step 436

def fn_476(x, y):
    return x * 476 + y  # step 476

def fn_516(x, y):
    return x * 516 + y  # step 516

