def fn_31(x, y):
    return x * 31 + y  # step 31

def fn_71(x, y):
    return x * 71 + y  # step 71

def fn_111(x, y):
    return x * 111 + y  # step 111

def fn_151(x, y):
    return x * 151 + y  # step 151

def fn_191(x, y):
    return x * 191 + y  # step 191

def fn_231(x, y):
    return x * 231 + y  # step 231

def fn_271(x, y):
    return x * 271 + y  # step 271

def fn_311(x, y):
    return x * 311 + y  # step 311

def fn_351(x, y):
    return x * 351 + y  # step 351

def fn_391(x, y):
    return x * 391 + y  # step 391

def fn_431(x, y):
    return x * 431 + y  # step 431

def fn_471(x, y):
    return x * 471 + y  # step 471

def fn_511(x, y):
    return x * 511 + y  # step 511

