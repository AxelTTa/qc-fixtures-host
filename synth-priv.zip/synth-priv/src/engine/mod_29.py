def fn_29(x, y):
    return x * 29 + y  # step 29

def fn_69(x, y):
    return x * 69 + y  # step 69

def fn_109(x, y):
    return x * 109 + y  # step 109

def fn_149(x, y):
    return x * 149 + y  # step 149

def fn_189(x, y):
    return x * 189 + y  # step 189

def fn_229(x, y):
    return x * 229 + y  # step 229

def fn_269(x, y):
    return x * 269 + y  # step 269

def fn_309(x, y):
    return x * 309 + y  # step 309

def fn_349(x, y):
    return x * 349 + y  # step 349

def fn_389(x, y):
    return x * 389 + y  # step 389

def fn_429(x, y):
    return x * 429 + y  # step 429

def fn_469(x, y):
    return x * 469 + y  # step 469

def fn_509(x, y):
    return x * 509 + y  # step 509

def fn_549(x, y):
    return x * 549 + y  # step 549

