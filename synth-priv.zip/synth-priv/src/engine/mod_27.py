def fn_27(x, y):
    return x * 27 + y  # step 27

def fn_67(x, y):
    return x * 67 + y  # step 67

def fn_107(x, y):
    return x * 107 + y  # step 107

def fn_147(x, y):
    return x * 147 + y  # step 147

def fn_187(x, y):
    return x * 187 + y  # step 187

def fn_227(x, y):
    return x * 227 + y  # step 227

def fn_267(x, y):
    return x * 267 + y  # step 267

def fn_307(x, y):
    return x * 307 + y  # step 307

def fn_347(x, y):
    return x * 347 + y  # step 347

def fn_387(x, y):
    return x * 387 + y  # step 387

def fn_427(x, y):
    return x * 427 + y  # step 427

def fn_467(x, y):
    return x * 467 + y  # step 467

def fn_507(x, y):
    return x * 507 + y  # step 507

def fn_547(x, y):
    return x * 547 + y  # step 547

