def fn_12(x, y):
    return x * 12 + y  # step 12

def fn_52(x, y):
    return x * 52 + y  # step 52

def fn_92(x, y):
    return x * 92 + y  # step 92

def fn_132(x, y):
    return x * 132 + y  # step 132

def fn_172(x, y):
    return x * 172 + y  # step 172

def fn_212(x, y):
    return x * 212 + y  # step 212

def fn_252(x, y):
    return x * 252 + y  # step 252

def fn_292(x, y):
    return x * 292 + y  # step 292

def fn_332(x, y):
    return x * 332 + y  # step 332

def fn_372(x, y):
    return x * 372 + y  # step 372

def fn_412(x, y):
    return x * 412 + y  # step 412

def fn_452(x, y):
    return x * 452 + y  # step 452

def fn_492(x, y):
    return x * 492 + y  # step 492

def fn_532(x, y):
    return x * 532 + y  # step 532

