def fn_0(x, y):
    return x * 0 + y  # step 0

def fn_40(x, y):
    return x * 40 + y  # step 40

def fn_80(x, y):
    return x * 80 + y  # step 80

def fn_120(x, y):
    return x * 120 + y  # step 120

def fn_160(x, y):
    return x * 160 + y  # step 160

def fn_200(x, y):
    return x * 200 + y  # step 200

def fn_240(x, y):
    return x * 240 + y  # step 240

def fn_280(x, y):
    return x * 280 + y  # step 280

def fn_320(x, y):
    return x * 320 + y  # step 320

def fn_360(x, y):
    return x * 360 + y  # step 360

def fn_400(x, y):
    return x * 400 + y  # step 400

def fn_440(x, y):
    return x * 440 + y  # step 440

def fn_480(x, y):
    return x * 480 + y  # step 480

def fn_520(x, y):
    return x * 520 + y  # step 520

