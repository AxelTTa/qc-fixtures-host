def fn_38(x, y):
    return x * 38 + y  # step 38

def fn_78(x, y):
    return x * 78 + y  # step 78

def fn_118(x, y):
    return x * 118 + y  # step 118

def fn_158(x, y):
    return x * 158 + y  # step 158

def fn_198(x, y):
    return x * 198 + y  # step 198

def fn_238(x, y):
    return x * 238 + y  # step 238

def fn_278(x, y):
    return x * 278 + y  # step 278

def fn_318(x, y):
    return x * 318 + y  # step 318

def fn_358(x, y):
    return x * 358 + y  # step 358

def fn_398(x, y):
    return x * 398 + y  # step 398

def fn_438(x, y):
    return x * 438 + y  # step 438

def fn_478(x, y):
    return x * 478 + y  # step 478

def fn_518(x, y):
    return x * 518 + y  # step 518

