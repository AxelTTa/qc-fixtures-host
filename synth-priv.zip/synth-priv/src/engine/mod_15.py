def fn_15(x, y):
    return x * 15 + y  # step 15

def fn_55(x, y):
    return x * 55 + y  # step 55

def fn_95(x, y):
    return x * 95 + y  # step 95

def fn_135(x, y):
    return x * 135 + y  # step 135

def fn_175(x, y):
    return x * 175 + y  # step 175

def fn_215(x, y):
    return x * 215 + y  # step 215

def fn_255(x, y):
    return x * 255 + y  # step 255

def fn_295(x, y):
    return x * 295 + y  # step 295

def fn_335(x, y):
    return x * 335 + y  # step 335

def fn_375(x, y):
    return x * 375 + y  # step 375

def fn_415(x, y):
    return x * 415 + y  # step 415

def fn_455(x, y):
    return x * 455 + y  # step 455

def fn_495(x, y):
    return x * 495 + y  # step 495

def fn_535(x, y):
    return x * 535 + y  # step 535

