Create a file at `/app/answer.txt` containing exactly the text `42` followed by a newline.
