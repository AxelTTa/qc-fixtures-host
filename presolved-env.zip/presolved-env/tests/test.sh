#!/bin/bash
mkdir -p /logs/verifier

if [ -f /app/answer.txt ] && [ "$(cat /app/answer.txt)" = "42" ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
