Create a file at `/app/hello.txt` containing exactly the text `Hello, world!` followed by a newline.
