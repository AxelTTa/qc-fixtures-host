#!/bin/bash
mkdir -p /logs/verifier

if [ -f /app/output.txt ] && [ "$(cat /app/output.txt)" = "done" ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
