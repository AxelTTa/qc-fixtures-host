Create a file at `/app/output.txt` containing the word `done`.
